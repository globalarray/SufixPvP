<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\level\format\io;

use pocketmine\level\format\Chunk;
use pocketmine\level\Level;
use pocketmine\nbt\NBT;
use pocketmine\network\mcpe\protocol\BatchPacket;
use pocketmine\network\mcpe\protocol\FullChunkDataPacket;
use pocketmine\scheduler\AsyncTask;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\Server;
use pocketmine\tile\Spawnable;

class ChunkRequestTask extends AsyncTask{

	protected $levelId;

	protected $chunk;
	protected $chunkX;
	protected $chunkZ;

	protected $tiles;

	protected $compressionLevel;

	public function __construct(Level $level, Chunk $chunk){
		$this->levelId = $level->getId();
		$this->compressionLevel = $level->getServer()->networkCompressionLevel;

		$this->chunk = $chunk->fastSerialize();
		$this->chunkX = $chunk->getX();
		$this->chunkZ = $chunk->getZ();

		//TODO: serialize tiles with chunks
		$tiles = "";
		$nbt = new NBT(NBT::LITTLE_ENDIAN);
		foreach($chunk->getTiles() as $tile){
			if($tile instanceof Spawnable){
				$nbt->setData($tile->getSpawnCompound());
				$tiles .= $nbt->write(true);
			}
		}

		$this->tiles = $tiles;
	}

	public function onRun() {
		$chunk = Chunk::fastDeserialize($this->chunk);

		$result = [];

		$protocols = [ProtocolInfo::CURRENT_PROTOCOL, ProtocolInfo::MULTIVERSION_PROTOCOL];

		foreach($protocols as $protocol){
			$pk = new FullChunkDataPacket();
			$pk->chunkX = $this->chunkX;
			$pk->chunkZ = $this->chunkZ;
			$pk->data = $chunk->networkSerialize($protocol) . $this->tiles;

			$batch = new BatchPacket();
			$batch->addPacket($pk);
			$batch->setCompressionLevel($this->compressionLevel);
			$batch->encode();

			$result[$protocol] = $batch->buffer;
		}

		$this->setResult($result);
	}

	public function onCompletion(Server $server) {
		$level = $server->getLevel($this->levelId);
		if ($level instanceof Level) {
			if ($this->hasResult()) {
				$packets = [];

				foreach ($this->getResult() as $protocol => $buffer) {
					$batch = new BatchPacket($buffer);
					assert(strlen($batch->buffer) > 0);
					$batch->isEncoded = true;
					$packets[$protocol] = $batch;
				}
				$level->chunkRequestCallback($this->chunkX, $this->chunkZ, $packets);
			}else{
				$server->getLogger()->error("Chunk request for level #" . $this->levelId . ", x=" . $this->chunkX . ", z=" . $this->chunkZ . " doesn't have any result data");
			}
		}else{
			$server->getLogger()->debug("Dropped chunk task due to level not loaded");
		}
	}

}